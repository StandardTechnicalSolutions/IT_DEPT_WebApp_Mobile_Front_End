
<?php 

    $placeholder1 = "<li><a href='/tss/exss/?location=home'>Home</a></li>";
    $placeholder2 = "<li><a href='/tss/exss/?location=equipment'>Equipment</a></li>";
    $placeholder3 = "<li><a href='/tss/exss/?location=map'>Map</a></li>";
    $placeholder4 = "<li><a href='/tss/exss/?location=contact'>Contact</a></li>";
    $placeholder5 = "<li><a href='/tss/exss/?location=orderForm'>Order Scantron</a></li>";
    $placeholder6 = "<li><a href='/tss/exss/?location=reporttype'>Report Type</a></li>";
    $content_placeholder = '
        <h1 id="order-form-heading">Thank You For Ordering!!!</h2>
        <a id="home-button" href="?location=home">Home</a>
    ';
    $extraJsFunction = "";