<?php 
$placeholderHeader = "<ul class='temp-header' id='equipLink'>
                    <li class='equipmentLink'><a class='Scan' href='#'>Scantron OpScan6</a></li>
                    <li class='equipmentLink'><a class='OMR' href='#'>Remark Classic OMR v5.0</a></li>
                    <li class='equipmentLink'><a class='EliteDesk' href='#'>HP EliteDesk 800 G1</a></li>
                    <li class='equipmentLink'><a class='Windows' href='#'>Microsoft Windows 10 Education</a></li>
                </ul>";
$placeholder1 = "<li class='equipmentLink'><a class='Scan' href='#'>Scantron OpScan6</a></li>";
$placeholder2 = "<li class='equipmentLink'><a class='OMR' href='#'>Remark Classic OMR v5.0</a></li>";
$placeholder3 = "<li class='equipmentLink'><a class='EliteDesk' href='#'>HP EliteDesk 800 G1</a></li>";
$placeholder4 = "<li class='equipmentLink'><a class='Windows' href='#'>Microsoft Windows 10 Education</a></li>";
$placeholder5 = "<li class='equipmentLink'><a href='/tss/exss/?location=home'>Home</a></li>";
$placeholder6 = "<li class='equipmentLink'><a href='/tss/exss/?location=orderForm'>Order Scantron</a></li>";

$content_placeholder = "";
$extraJsFunction = "/tss/exss/javascript/equipImages.js";